package math.arithmetic;

public class AdditionChildren extends MathOperationParent {

    @Override
    public double calculate() {

        return getFirstNumber() + getSecondNumber();
    }
}
