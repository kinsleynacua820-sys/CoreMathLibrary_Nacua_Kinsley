package math.arithmetic;

public class DivisionChlidren extends MathOperationParent {

    @Override
    public double calculate(){
        if (getSecondNumber() == 0) {
            System.out.println("Error: Cannot divide by zero.");
            return 0;
        }
        return getFirstNumber() / getSecondNumber();
    }

}
