package math.arithmetic;

public class MultiplicationChildren extends MathOperationParent {

    @Override
    public double calculate(){

        return getFirstNumber() * getSecondNumber();
    }
}
