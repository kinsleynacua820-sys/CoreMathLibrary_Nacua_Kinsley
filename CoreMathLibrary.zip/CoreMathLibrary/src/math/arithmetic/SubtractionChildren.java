package math.arithmetic;

public class SubtractionChildren extends MathOperationParent {

    @Override
    public double calculate() {

        return getFirstNumber() - getSecondNumber();
    }
}
