package math.number;

public class FactorialChildren extends NumberOperationParent {

    public long calculateFactorial() {

        int num = getNumber();
        long result = 1;

        for (int i = 1; i <= num; i++) {
            result *= i;
        }

        return result;
    }
}
