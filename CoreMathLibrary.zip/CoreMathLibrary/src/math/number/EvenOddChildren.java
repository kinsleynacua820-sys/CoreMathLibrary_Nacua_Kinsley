package math.number;

public class EvenOddChildren extends NumberOperationParent {

    public boolean isEven() {
        return getNumber() % 2 == 0;
    }

    public boolean isOdd() {
        return getNumber() % 2 != 0;
    }
}
