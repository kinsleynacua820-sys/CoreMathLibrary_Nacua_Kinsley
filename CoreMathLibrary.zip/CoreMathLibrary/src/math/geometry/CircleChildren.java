package math.geometry;

public class CircleChildren extends ShapeParent{

    private double radius;

    public void setRadius(double radius) {
        if (radius < 0) {
            System.out.println("Invalid radius.");
            return;
        }
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    @Override
    public double calculateArea() {
        return Math.PI * radius * radius;
    }

    @Override
    public double calculatePerimeter() {
        return 2 * Math.PI * radius;
    }
}
