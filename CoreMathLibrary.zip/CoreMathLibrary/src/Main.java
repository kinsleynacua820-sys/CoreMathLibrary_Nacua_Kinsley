import math.arithmetic.AdditionChildren;
import math.arithmetic.DivisionChlidren;
import math.arithmetic.SubtractionChildren;
import math.arithmetic.MultiplicationChildren;
import math.geometry.CircleChildren;
import math.geometry.RectangleChildren;
import math.number.PrimeCheckChildren;
import math.number.FactorialChildren;
import math.number.EvenOddChildren;

public class Main {

    public static void main(String[] args) {

        AdditionChildren add = new AdditionChildren();
        add.setFirstNumber(15);
        add.setSecondNumber(10);

        System.out.println("Addition result: " + add.calculate());

        DivisionChlidren div = new DivisionChlidren();
        div.setFirstNumber(20);
        div.setSecondNumber(5);

        System.out.println("Division result: " + div.calculate());

        MultiplicationChildren multiply = new MultiplicationChildren();
        multiply.setFirstNumber(5);
        multiply.setSecondNumber(3);

        System.out.println("Multiplication result: " + multiply.calculate());

        SubtractionChildren subtract = new SubtractionChildren();
        subtract.setFirstNumber(10);
        subtract.setSecondNumber(5);

        System.out.println("Subtraction result: " + subtract.calculate());

        CircleChildren circle = new CircleChildren();
        circle.setRadius(5);
        System.out.println("Circle area: " + circle.calculateArea());

        RectangleChildren rect = new RectangleChildren();
        rect.setLength(4);
        rect.setWidth(6);
        System.out.println("Rectangle area: " + rect.calculateArea());

        PrimeCheckChildren prime = new PrimeCheckChildren();
        prime.setNumber(7);
        System.out.println("Is prime: " + prime.isPrime());

        FactorialChildren factorial = new FactorialChildren();
        factorial.setNumber(5);
        System.out.println("Factorial: " + factorial.calculateFactorial());

        EvenOddChildren evenOdd = new EvenOddChildren();
        evenOdd.setNumber(10);
        System.out.println("Is even: " + evenOdd.isEven());

    }
}
